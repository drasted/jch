const { fromEvent } = rxjs;
const { map, startWith } = rxjs.operators;

const eleFromElement = document.querySelector(".from-event");
const eleFromElementElement = document.querySelector(".from-event-element");
const eleStream = document.querySelector("#stream");
const eleTextPath = document.querySelector("#textPath");
const eleClientX = document.querySelector(".client-x");
const eleClientY = document.querySelector(".client-y");
const eleClientXValue = document.querySelector(".client-x-value");
const eleClientYValue = document.querySelector(".client-y-value");

const eleFromElementTop = eleFromElement.getBoundingClientRect().top;
const eleFromElementLeft = eleFromElement.getBoundingClientRect().left;
const pathLength = eleTextPath.getTotalLength();

let bbox = eleFromElementElement.getBoundingClientRect();
const eleFromElementElementWidth = bbox.width;
const eleFromElementElementHeight = bbox.height / 2;

let startOffset = 0;
const mouseMoveObservable$ = fromEvent(eleFromElement, "mousemove");
mouseMoveObservable$.subscribe(({ clientX, clientY }) => {
	eleClientX.innerText = clientX;
	eleClientY.innerText = clientY;
	if (startOffset === 0) {
		moveData(clientX, clientY);
	}
	eleFromElementElement.style.cssText = `margin-left: ${
		clientX - eleFromElementLeft
	}px; margin-top: ${
		clientY - eleFromElementTop + document.documentElement.scrollTop
	}px;`;
});

let leaveInterval = null;
function moveData(clientX, clientY) {
	startOffset = -21;
	setStreamtext(`{clientX: ${clientX}, clientY: ${clientY}`);
	leaveInterval = setInterval(() => {
		startOffset += 20;
		eleStream.setAttribute("startOffset", startOffset);
		if (startOffset > pathLength) {
			clearInterval(leaveInterval);
			eleClientX.innerText = clientX;
			eleClientY.innerText = clientY;
			startOffset = 0;
			setStreamtext("no data");
			eleStream.setAttribute("startOffset", startOffset);
		}
	}, 2);
}

function setStreamtext(streamText) {
	eleStream.innerHTML = streamText;
}

const mouseEnter = fromEvent(eleFromElement, "mouseenter");
mouseEnter.subscribe(() => {
	if (leaveInterval) {
		clearInterval(leaveInterval);
	}
	startOffset = 0;
	setStreamtext("");
});

mouseMoveObservable$.subscribe(({ clientX, clientY }) => {
	eleClientXValue.innerText = clientX;
	eleClientYValue.innerText = clientY;
});
