package cn.hnu.cs.excel.annotation;

/**
 * @author dengxiangjun
 * @version 1.0
 * @created 17/3/16
 */
public enum ExcelObJectInstanceType {

    CONSTRUCTOR, METHOD;
}
