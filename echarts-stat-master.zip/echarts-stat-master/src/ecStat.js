define(function (require) {

    return {

        clustering: require('./clustering'),
        regression: require('./regression'),
        statistic: require('./statistic')

    };

});