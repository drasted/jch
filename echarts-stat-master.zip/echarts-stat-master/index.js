module.exports = require('./src/ecStat');
